// // import React, { useState, useEffect, useRef } from 'react';
// // import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// // const ExternalDeviceVoiceToText = () => {
// //   // State management
// //   const [audioDevices, setAudioDevices] = useState([]);
// //   const [selectedDevice, setSelectedDevice] = useState('');
// //   const [mediaStream, setMediaStream] = useState(null);
// //   const [isListening, setIsListening] = useState(false);
// //   const [error, setError] = useState('');

// //   // Speech recognition hook
// //   const {
// //     transcript,
// //     listening,
// //     resetTranscript,
// //     browserSupportsSpeechRecognition
// //   } = useSpeechRecognition();

// //   // Check browser compatibility
// //   if (!browserSupportsSpeechRecognition) {
// //     return <span>Browser doesn't support speech recognition.</span>;
// //   }

// //   // Load available audio devices on component mount
// //   useEffect(() => {
// //     const loadDevices = async () => {
// //       try {
// //         // Request permission first
// //         await navigator.mediaDevices.getUserMedia({ audio: true });
        
// //         // Get all devices
// //         const devices = await navigator.mediaDevices.enumerateDevices();
// //         const audioInputs = devices.filter(device => device.kind === 'audioinput');
        
// //         setAudioDevices(audioInputs);
        
// //         // Auto-select first device if available
// //         if (audioInputs.length > 0) {
// //           setSelectedDevice(audioInputs[0].deviceId);
// //         }
// //       } catch (err) {
// //         setError('Failed to access microphone devices: ' + err.message);
// //       }
// //     };

// //     loadDevices();

// //     // Cleanup on unmount
// //     return () => {
// //       if (mediaStream) {
// //         mediaStream.getTracks().forEach(track => track.stop());
// //       }
// //     };
// //   }, []);

// //   // Handle device selection
// //   const selectDevice = async (deviceId) => {
// //     try {
// //       // Stop current stream
// //       if (mediaStream) {
// //         mediaStream.getTracks().forEach(track => track.stop());
// //       }

// //       // Get new stream from selected device
// //       const stream = await navigator.mediaDevices.getUserMedia({
// //         audio: { 
// //           deviceId: deviceId ? { exact: deviceId } : undefined,
// //           echoCancellation: true,
// //           noiseSuppression: true,
// //           autoGainControl: true
// //         }
// //       });

// //       setMediaStream(stream);
// //       setSelectedDevice(deviceId);
// //       setError('');
// //     } catch (err) {
// //       setError('Error selecting device: ' + err.message);
// //     }
// //   };

// //   // Start listening with selected device
// //   const startListening = async () => {
// //     try {
// //       if (selectedDevice) {
// //         await selectDevice(selectedDevice);
// //       }

// //       await SpeechRecognition.startListening({ 
// //         continuous: true,
// //         language: 'en-US'
// //       });
      
// //       setIsListening(true);
// //       setError('');
// //     } catch (err) {
// //       setError('Failed to start listening: ' + err.message);
// //     }
// //   };

// //   // Stop listening
// //   const stopListening = () => {
// //     SpeechRecognition.stopListening();
// //     setIsListening(false);
// //   };

// //   // Clear transcript
// //   const clearTranscript = () => {
// //     resetTranscript();
// //   };

// //   // Copy transcript to clipboard
// //   const copyToClipboard = () => {
// //     navigator.clipboard.writeText(transcript);
// //   };

// //   return (
// //     <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
// //       <h1>External Device Voice to Text</h1>
      
// //       {/* Error Display */}
// //       {error && (
// //         <div style={{ 
// //           color: 'red', 
// //           backgroundColor: '#ffebee', 
// //           padding: '10px', 
// //           borderRadius: '4px',
// //           marginBottom: '20px'
// //         }}>
// //           {error}
// //         </div>
// //       )}

// //       {/* Device Selection */}
// //       <div style={{ marginBottom: '20px' }}>
// //         <label htmlFor="device-select" style={{ display: 'block', marginBottom: '10px' }}>
// //           Select Audio Input Device:
// //         </label>
// //         <select
// //           id="device-select"
// //           value={selectedDevice}
// //           onChange={(e) => selectDevice(e.target.value)}
// //           style={{ 
// //             width: '100%', 
// //             padding: '10px', 
// //             fontSize: '16px',
// //             borderRadius: '4px',
// //             border: '1px solid #ccc'
// //           }}
// //         >
// //           <option value="">Default Device</option>
// //           {audioDevices.map(device => (
// //             <option key={device.deviceId} value={device.deviceId}>
// //               {device.label || `Device ${device.deviceId.slice(0, 8)}...`}
// //             </option>
// //           ))}
// //         </select>
// //       </div>

// //       {/* Control Buttons */}
// //       <div style={{ marginBottom: '20px' }}>
// //         <button
// //           onClick={startListening}
// //           disabled={isListening || listening}
// //           style={{
// //             backgroundColor: listening ? '#4CAF50' : '#2196F3',
// //             color: 'white',
// //             padding: '12px 24px',
// //             marginRight: '10px',
// //             border: 'none',
// //             borderRadius: '4px',
// //             fontSize: '16px',
// //             cursor: listening ? 'not-allowed' : 'pointer',
// //             opacity: listening ? 0.7 : 1
// //           }}
// //         >
// //           {listening ? 'Listening...' : 'Start Listening'}
// //         </button>

// //         <button
// //           onClick={stopListening}
// //           disabled={!listening}
// //           style={{
// //             backgroundColor: '#f44336',
// //             color: 'white',
// //             padding: '12px 24px',
// //             marginRight: '10px',
// //             border: 'none',
// //             borderRadius: '4px',
// //             fontSize: '16px',
// //             cursor: !listening ? 'not-allowed' : 'pointer',
// //             opacity: !listening ? 0.7 : 1
// //           }}
// //         >
// //           Stop
// //         </button>

// //         <button
// //           onClick={clearTranscript}
// //           style={{
// //             backgroundColor: '#FF9800',
// //             color: 'white',
// //             padding: '12px 24px',
// //             marginRight: '10px',
// //             border: 'none',
// //             borderRadius: '4px',
// //             fontSize: '16px',
// //             cursor: 'pointer'
// //           }}
// //         >
// //           Clear
// //         </button>

// //         <button
// //           onClick={copyToClipboard}
// //           disabled={!transcript}
// //           style={{
// //             backgroundColor: '#9C27B0',
// //             color: 'white',
// //             padding: '12px 24px',
// //             border: 'none',
// //             borderRadius: '4px',
// //             fontSize: '16px',
// //             cursor: transcript ? 'pointer' : 'not-allowed',
// //             opacity: transcript ? 1 : 0.7
// //           }}
// //         >
// //           Copy Text
// //         </button>
// //       </div>

// //       {/* Status Indicator */}
// //       <div style={{ marginBottom: '20px' }}>
// //         <p style={{ 
// //           fontSize: '18px',
// //           fontWeight: 'bold',
// //           color: listening ? '#4CAF50' : '#666'
// //         }}>
// //           Microphone: {listening ? 'ON' : 'OFF'}
// //         </p>
// //         <p style={{ fontSize: '14px', color: '#666' }}>
// //           Selected Device: {
// //             audioDevices.find(d => d.deviceId === selectedDevice)?.label || 
// //             'Default Device'
// //           }
// //         </p>
// //       </div>

// //       {/* Transcript Display */}
// //       <div>
// //         <h3>Recognized Text:</h3>
// //         <textarea
// //           value={transcript}
// //           readOnly
// //           placeholder="Spoken text will appear here..."
// //           style={{
// //             width: '100%',
// //             minHeight: '200px',
// //             padding: '15px',
// //             fontSize: '16px',
// //             lineHeight: '1.5',
// //             border: '1px solid #ccc',
// //             borderRadius: '4px',
// //             backgroundColor: '#f9f9f9',
// //             resize: 'vertical'
// //           }}
// //         />
// //         <p style={{ fontSize: '12px', color: '#666', marginTop: '10px' }}>
// //           Character count: {transcript.length}
// //         </p>
// //       </div>

// //       {/* Instructions */}
// //       <div style={{ 
// //         marginTop: '30px',
// //         padding: '15px',
// //         backgroundColor: '#e3f2fd',
// //         borderRadius: '4px'
// //       }}>
// //         <h4>Instructions:</h4>
// //         <ul>
// //           <li>Select your external microphone from the dropdown</li>
// //           <li>Click "Start Listening" to begin voice recognition</li>
// //           <li>Speak clearly into your selected device</li>
// //           <li>Click "Stop" when finished</li>
// //           <li>Use "Copy Text" to copy the transcript</li>
// //         </ul>
// //       </div>
// //     </div>
// //   );
// // };

// // export default ExternalDeviceVoiceToText;









// import React, { useState, useEffect, useRef } from 'react';
// // Add this import for Next.js or if having async issues
// import 'regenerator-runtime/runtime';
// import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// const ExternalDeviceVoiceToText = () => {
//   // State management
//   const [audioDevices, setAudioDevices] = useState([]);
//   const [selectedDevice, setSelectedDevice] = useState('');
//   const [mediaStream, setMediaStream] = useState(null);
//   const [isListening, setIsListening] = useState(false);
//   const [error, setError] = useState('');
//   const [permissionGranted, setPermissionGranted] = useState(false);

//   // Speech recognition hook
//   const {
//     transcript,
//     listening,
//     resetTranscript,
//     browserSupportsSpeechRecognition
//   } = useSpeechRecognition();

//   // Check HTTPS requirement
//   const isHttps = window.location.protocol === 'https:' || window.location.hostname === 'localhost';

//   // Browser compatibility check
//   if (!browserSupportsSpeechRecognition) {
//     return (
//       <div style={{ padding: '20px', color: 'red' }}>
//         <h2>Browser Not Supported</h2>
//         <p>Your browser doesn't support speech recognition.</p>
//         <p>Please use:</p>
//         <ul>
//           <li>Chrome (recommended)</li>
//           <li>Edge</li>
//           <li>Safari (latest version)</li>
//         </ul>
//       </div>
//     );
//   }

//   // HTTPS requirement check
//   if (!isHttps) {
//     return (
//       <div style={{ padding: '20px', color: 'red' }}>
//         <h2>HTTPS Required</h2>
//         <p>Speech recognition requires HTTPS or localhost to work.</p>
//         <p>Please access this page via HTTPS or localhost.</p>
//       </div>
//     );
//   }

//   // Load available audio devices and request permissions
//   useEffect(() => {
//     const loadDevicesAndPermissions = async () => {
//       try {
//         // First, explicitly request microphone permission
//         const stream = await navigator.mediaDevices.getUserMedia({ 
//           audio: {
//             echoCancellation: true,
//             noiseSuppression: true,
//             autoGainControl: true
//           }
//         });
        
//         setPermissionGranted(true);
        
//         // Stop the test stream
//         stream.getTracks().forEach(track => track.stop());
        
//         // Now get all devices
//         const devices = await navigator.mediaDevices.enumerateDevices();
//         const audioInputs = devices.filter(device => device.kind === 'audioinput');
        
//         console.log('Available audio devices:', audioInputs);
//         setAudioDevices(audioInputs);
        
//         // Auto-select first device if available
//         if (audioInputs.length > 0) {
//           setSelectedDevice(audioInputs[0].deviceId);
//         }
        
//         setError('');
//       } catch (err) {
//         console.error('Permission/Device error:', err);
//         setPermissionGranted(false);
//         setError(`Failed to access microphone: ${err.message}. Please allow microphone access and refresh the page.`);
//       }
//     };

//     loadDevicesAndPermissions();

//     // Cleanup on unmount
//     return () => {
//       if (mediaStream) {
//         mediaStream.getTracks().forEach(track => track.stop());
//       }
//     };
//   }, []);

//   // Handle device selection with improved error handling
//   const selectDevice = async (deviceId) => {
//     try {
//       console.log('Selecting device:', deviceId);
      
//       // Stop current stream
//       if (mediaStream) {
//         mediaStream.getTracks().forEach(track => track.stop());
//       }

//       // Get new stream from selected device
//       const stream = await navigator.mediaDevices.getUserMedia({
//         audio: { 
//           deviceId: deviceId ? { exact: deviceId } : undefined,
//           echoCancellation: true,
//           noiseSuppression: true,
//           autoGainControl: true,
//           sampleRate: 16000 // Optimal for speech recognition
//         }
//       });

//       console.log('Stream created successfully');
//       setMediaStream(stream);
//       setSelectedDevice(deviceId);
//       setError('');
//     } catch (err) {
//       console.error('Device selection error:', err);
//       setError(`Error selecting device: ${err.message}`);
//     }
//   };

//   // Improved start listening with better error handling
//   const startListening = async () => {
//     try {
//       if (!permissionGranted) {
//         setError('Microphone permission not granted. Please refresh and allow access.');
//         return;
//       }

//       // Ensure device is selected
//       if (selectedDevice) {
//         await selectDevice(selectedDevice);
//       }

//       // Add error event listeners for SpeechRecognition
//       const recognition = SpeechRecognition.getRecognition();
//       if (recognition) {
//         recognition.onerror = (event) => {
//           console.error('Speech recognition error:', event.error);
//           setError(`Speech recognition error: ${event.error}`);
//           setIsListening(false);
//         };

//         recognition.onend = () => {
//           console.log('Speech recognition ended');
//           setIsListening(false);
//         };
//       }

//       // Start listening with improved configuration
//       await SpeechRecognition.startListening({ 
//         continuous: true,
//         interimResults: true,
//         language: 'en-US' // Try different languages: 'en-GB', 'es-ES', etc.
//       });
      
//       setIsListening(true);
//       setError('');
//       console.log('Speech recognition started successfully');
//     } catch (err) {
//       console.error('Start listening error:', err);
//       setError(`Failed to start listening: ${err.message}`);
//       setIsListening(false);
//     }
//   };

//   // Enhanced stop listening
//   const stopListening = () => {
//     try {
//       SpeechRecognition.stopListening();
//       setIsListening(false);
//       console.log('Speech recognition stopped');
//     } catch (err) {
//       console.error('Stop listening error:', err);
//       setError(`Error stopping: ${err.message}`);
//     }
//   };

//   // Test microphone function
//   const testMicrophone = async () => {
//     try {
//       const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
//       const audioContext = new AudioContext();
//       const analyser = audioContext.createAnalyser();
//       const microphone = audioContext.createMediaStreamSource(stream);
//       const dataArray = new Uint8Array(analyser.frequencyBinCount);
      
//       microphone.connect(analyser);
      
//       // Simple volume check
//       const checkVolume = () => {
//         analyser.getByteFrequencyData(dataArray);
//         const volume = dataArray.reduce((sum, value) => sum + value) / dataArray.length;
//         console.log('Microphone volume level:', volume);
//         return volume > 10; // Adjust threshold as needed
//       };
      
//       const hasSound = checkVolume();
      
//       // Cleanup
//       stream.getTracks().forEach(track => track.stop());
//       audioContext.close();
      
//       if (hasSound) {
//         setError('');
//         alert('Microphone is working! Volume detected.');
//       } else {
//         setError('Microphone connected but no audio detected. Please speak louder or check your microphone.');
//       }
//     } catch (err) {
//       setError(`Microphone test failed: ${err.message}`);
//     }
//   };

//   // Clear transcript
//   const clearTranscript = () => {
//     resetTranscript();
//   };

//   // Copy transcript to clipboard
//   const copyToClipboard = async () => {
//     try {
//       await navigator.clipboard.writeText(transcript);
//       alert('Text copied to clipboard!');
//     } catch (err) {
//       console.error('Copy failed:', err);
//       // Fallback
//       const textArea = document.createElement('textarea');
//       textArea.value = transcript;
//       document.body.appendChild(textArea);
//       textArea.select();
//       document.execCommand('copy');
//       document.body.removeChild(textArea);
//       alert('Text copied to clipboard!');
//     }
//   };

//   return (
//     <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
//       <h1>External Device Voice to Text</h1>
      
//       {/* Permission Status */}
//       <div style={{ 
//         padding: '10px', 
//         marginBottom: '20px',
//         backgroundColor: permissionGranted ? '#e8f5e8' : '#ffebee',
//         borderRadius: '4px',
//         border: `1px solid ${permissionGranted ? '#4CAF50' : '#f44336'}`
//       }}>
//         <strong>Permission Status:</strong> {permissionGranted ? '✓ Granted' : '✗ Not Granted'}
//         {!permissionGranted && (
//           <p style={{ margin: '10px 0 0 0', fontSize: '14px' }}>
//             Please refresh the page and allow microphone access when prompted.
//           </p>
//         )}
//       </div>

//       {/* Error Display */}
//       {error && (
//         <div style={{ 
//           color: 'red', 
//           backgroundColor: '#ffebee', 
//           padding: '10px', 
//           borderRadius: '4px',
//           marginBottom: '20px'
//         }}>
//           <strong>Error:</strong> {error}
//         </div>
//       )}

//       {/* Debug Info */}
//       <div style={{ 
//         fontSize: '12px', 
//         color: '#666', 
//         marginBottom: '20px',
//         padding: '10px',
//         backgroundColor: '#f5f5f5',
//         borderRadius: '4px'
//       }}>
//         <strong>Debug Info:</strong><br/>
//         HTTPS: {isHttps ? '✓' : '✗'}<br/>
//         Browser Support: {browserSupportsSpeechRecognition ? '✓' : '✗'}<br/>
//         Permission: {permissionGranted ? '✓' : '✗'}<br/>
//         Devices Found: {audioDevices.length}<br/>
//         Currently Listening: {listening ? '✓' : '✗'}
//       </div>

//       {permissionGranted && (
//         <>
//           {/* Device Selection */}
//           <div style={{ marginBottom: '20px' }}>
//             <label htmlFor="device-select" style={{ display: 'block', marginBottom: '10px' }}>
//               Select Audio Input Device:
//             </label>
//             <select
//               id="device-select"
//               value={selectedDevice}
//               onChange={(e) => selectDevice(e.target.value)}
//               style={{ 
//                 width: '100%', 
//                 padding: '10px', 
//                 fontSize: '16px',
//                 borderRadius: '4px',
//                 border: '1px solid #ccc'
//               }}
//             >
//               <option value="">Default Device</option>
//               {audioDevices.map(device => (
//                 <option key={device.deviceId} value={device.deviceId}>
//                   {device.label || `Device ${device.deviceId.slice(0, 8)}...`}
//                 </option>
//               ))}
//             </select>
//           </div>

//           {/* Control Buttons */}
//           <div style={{ marginBottom: '20px' }}>
//             <button
//               onClick={startListening}
//               disabled={isListening || listening}
//               style={{
//                 backgroundColor: listening ? '#4CAF50' : '#2196F3',
//                 color: 'white',
//                 padding: '12px 24px',
//                 marginRight: '10px',
//                 marginBottom: '10px',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontSize: '16px',
//                 cursor: listening ? 'not-allowed' : 'pointer',
//                 opacity: listening ? 0.7 : 1
//               }}
//             >
//               {listening ? 'Listening...' : 'Start Listening'}
//             </button>

//             <button
//               onClick={stopListening}
//               disabled={!listening}
//               style={{
//                 backgroundColor: '#f44336',
//                 color: 'white',
//                 padding: '12px 24px',
//                 marginRight: '10px',
//                 marginBottom: '10px',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontSize: '16px',
//                 cursor: !listening ? 'not-allowed' : 'pointer',
//                 opacity: !listening ? 0.7 : 1
//               }}
//             >
//               Stop
//             </button>

//             <button
//               onClick={clearTranscript}
//               style={{
//                 backgroundColor: '#FF9800',
//                 color: 'white',
//                 padding: '12px 24px',
//                 marginRight: '10px',
//                 marginBottom: '10px',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontSize: '16px',
//                 cursor: 'pointer'
//               }}
//             >
//               Clear
//             </button>

//             <button
//               onClick={testMicrophone}
//               style={{
//                 backgroundColor: '#9C27B0',
//                 color: 'white',
//                 padding: '12px 24px',
//                 marginRight: '10px',
//                 marginBottom: '10px',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontSize: '16px',
//                 cursor: 'pointer'
//               }}
//             >
//               Test Mic
//             </button>

//             <button
//               onClick={copyToClipboard}
//               disabled={!transcript}
//               style={{
//                 backgroundColor: '#607D8B',
//                 color: 'white',
//                 padding: '12px 24px',
//                 marginBottom: '10px',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontSize: '16px',
//                 cursor: transcript ? 'pointer' : 'not-allowed',
//                 opacity: transcript ? 1 : 0.7
//               }}
//             >
//               Copy Text
//             </button>
//           </div>

//           {/* Status Indicator */}
//           <div style={{ marginBottom: '20px' }}>
//             <p style={{ 
//               fontSize: '18px',
//               fontWeight: 'bold',
//               color: listening ? '#4CAF50' : '#666'
//             }}>
//               Microphone: {listening ? '🔴 RECORDING' : '⚪ READY'}
//             </p>
//             <p style={{ fontSize: '14px', color: '#666' }}>
//               Selected Device: {
//                 audioDevices.find(d => d.deviceId === selectedDevice)?.label || 
//                 'Default Device'
//               }
//             </p>
//           </div>

//           {/* Transcript Display */}
//           <div>
//             <h3>Recognized Text:</h3>
//             <textarea
//               value={transcript}
//               readOnly
//               placeholder="Spoken text will appear here... Make sure to speak clearly and loudly."
//               style={{
//                 width: '100%',
//                 minHeight: '200px',
//                 padding: '15px',
//                 fontSize: '16px',
//                 lineHeight: '1.5',
//                 border: '1px solid #ccc',
//                 borderRadius: '4px',
//                 backgroundColor: '#f9f9f9',
//                 resize: 'vertical'
//               }}
//             />
//             <p style={{ fontSize: '12px', color: '#666', marginTop: '10px' }}>
//               Character count: {transcript.length}
//             </p>
//           </div>
//         </>
//       )}

//       {/* Troubleshooting Tips */}
//       <div style={{ 
//         marginTop: '30px',
//         padding: '15px',
//         backgroundColor: '#e3f2fd',
//         borderRadius: '4px'
//       }}>
//         <h4>Troubleshooting Tips:</h4>
//         <ul>
//           <li><strong>No Recognition:</strong> Speak louder and more clearly</li>
//           <li><strong>Permission Issues:</strong> Refresh page and allow microphone access</li>
//           <li><strong>HTTPS Required:</strong> Use HTTPS or localhost</li>
//           <li><strong>Internet Required:</strong> Chrome needs internet for speech recognition</li>
//           <li><strong>Mobile Issues:</strong> Use latest Chrome/Safari, may not work in PWA</li>
//           <li><strong>Device Not Found:</strong> Check if external mic is properly connected</li>
//         </ul>
//       </div>
//     </div>
//   );
// };

// export default ExternalDeviceVoiceToText;








// import React, { useState, useEffect, useRef } from 'react';
// // Add this import for Next.js or if having async issues
// import 'regenerator-runtime/runtime';
// import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// const ExternalDeviceVoiceToText = () => {
//   // Existing STT state management
//   const [audioDevices, setAudioDevices] = useState([]);
//   const [selectedDevice, setSelectedDevice] = useState('');
//   const [mediaStream, setMediaStream] = useState(null);
//   const [isListening, setIsListening] = useState(false);
//   const [error, setError] = useState('');
//   const [permissionGranted, setPermissionGranted] = useState(false);

//   // New TTS state management
//   const [ttsText, setTtsText] = useState('');
//   const [voices, setVoices] = useState([]);
//   const [selectedVoice, setSelectedVoice] = useState(null);
//   const [isSpeaking, setIsSpeaking] = useState(false);
//   const [isPaused, setIsPaused] = useState(false);
//   const [utterance, setUtterance] = useState(null);
  
//   // TTS Settings
//   const [speechRate, setSpeechRate] = useState(1);
//   const [speechPitch, setSpeechPitch] = useState(1);
//   const [speechVolume, setSpeechVolume] = useState(1);
//   const [ttsError, setTtsError] = useState('');

//   // Speech recognition hook
//   const {
//     transcript,
//     listening,
//     resetTranscript,
//     browserSupportsSpeechRecognition
//   } = useSpeechRecognition();

//   // Check HTTPS requirement
//   const isHttps = window.location.protocol === 'https:' || window.location.hostname === 'localhost';

//   // Check TTS support
//   const supportsTTS = 'speechSynthesis' in window;

//   // Browser compatibility check
//   if (!browserSupportsSpeechRecognition || !supportsTTS) {
//     return (
//       <div style={{ padding: '20px', color: 'red' }}>
//         <h2>Browser Not Supported</h2>
//         <p>Your browser doesn't support speech recognition or text-to-speech.</p>
//         <p>Missing features:</p>
//         <ul>
//           {!browserSupportsSpeechRecognition && <li>Speech Recognition</li>}
//           {!supportsTTS && <li>Text-to-Speech</li>}
//         </ul>
//         <p>Please use Chrome (recommended), Edge, or Safari (latest version).</p>
//       </div>
//     );
//   }

//   // HTTPS requirement check
//   if (!isHttps) {
//     return (
//       <div style={{ padding: '20px', color: 'red' }}>
//         <h2>HTTPS Required</h2>
//         <p>Speech recognition and synthesis require HTTPS or localhost to work.</p>
//         <p>Please access this page via HTTPS or localhost.</p>
//       </div>
//     );
//   }

//   // Load TTS voices
//   useEffect(() => {
//     const loadVoices = () => {
//       const availableVoices = window.speechSynthesis.getVoices();
//       console.log('Available TTS voices:', availableVoices);
//       setVoices(availableVoices);
      
//       // Auto-select first English voice or first available voice
//       const englishVoice = availableVoices.find(voice => voice.lang.startsWith('en'));
//       setSelectedVoice(englishVoice || availableVoices[0]);
//     };

//     // Load voices immediately
//     loadVoices();
    
//     // Also load when voices change (some browsers load voices asynchronously)
//     if (window.speechSynthesis.onvoiceschanged !== undefined) {
//       window.speechSynthesis.onvoiceschanged = loadVoices;
//     }
//   }, []);

//   // Load available audio devices and request permissions
//   useEffect(() => {
//     const loadDevicesAndPermissions = async () => {
//       try {
//         const stream = await navigator.mediaDevices.getUserMedia({ 
//           audio: {
//             echoCancellation: true,
//             noiseSuppression: true,
//             autoGainControl: true
//           }
//         });
        
//         setPermissionGranted(true);
//         stream.getTracks().forEach(track => track.stop());
        
//         const devices = await navigator.mediaDevices.enumerateDevices();
//         const audioInputs = devices.filter(device => device.kind === 'audioinput');
        
//         console.log('Available audio devices:', audioInputs);
//         setAudioDevices(audioInputs);
        
//         if (audioInputs.length > 0) {
//           setSelectedDevice(audioInputs[0].deviceId);
//         }
        
//         setError('');
//       } catch (err) {
//         console.error('Permission/Device error:', err);
//         setPermissionGranted(false);
//         setError(`Failed to access microphone: ${err.message}. Please allow microphone access and refresh the page.`);
//       }
//     };

//     loadDevicesAndPermissions();

//     return () => {
//       if (mediaStream) {
//         mediaStream.getTracks().forEach(track => track.stop());
//       }
//       // Stop any ongoing TTS
//       if (window.speechSynthesis.speaking) {
//         window.speechSynthesis.cancel();
//       }
//     };
//   }, []);

//   // TTS Functions
//   const createUtterance = (text) => {
//     const newUtterance = new SpeechSynthesisUtterance(text);
//     newUtterance.voice = selectedVoice;
//     newUtterance.rate = speechRate;
//     newUtterance.pitch = speechPitch;
//     newUtterance.volume = speechVolume;

//     // Event listeners
//     newUtterance.onstart = () => {
//       console.log('TTS started');
//       setIsSpeaking(true);
//       setIsPaused(false);
//       setTtsError('');
//     };

//     newUtterance.onend = () => {
//       console.log('TTS ended');
//       setIsSpeaking(false);
//       setIsPaused(false);
//     };

//     newUtterance.onerror = (event) => {
//       console.error('TTS error:', event.error);
//       setTtsError(`TTS Error: ${event.error}`);
//       setIsSpeaking(false);
//       setIsPaused(false);
//     };

//     newUtterance.onpause = () => {
//       console.log('TTS paused');
//       setIsPaused(true);
//     };

//     newUtterance.onresume = () => {
//       console.log('TTS resumed');
//       setIsPaused(false);
//     };

//     return newUtterance;
//   };

//   const speakText = (text = ttsText) => {
//     if (!text.trim()) {
//       setTtsError('Please enter text to speak');
//       return;
//     }

//     try {
//       // Stop any current speech
//       window.speechSynthesis.cancel();
      
//       const newUtterance = createUtterance(text);
//       setUtterance(newUtterance);
//       window.speechSynthesis.speak(newUtterance);
//     } catch (err) {
//       console.error('Speak error:', err);
//       setTtsError(`Failed to speak: ${err.message}`);
//     }
//   };

//   // NEW: Handle Enter key press in TTS textarea
//   const handleTtsKeyDown = (e) => {
//     if (e.key === 'Enter') {
//       // Check if Shift+Enter (for new line) or just Enter (for speak)
//       if (e.shiftKey) {
//         // Allow new line when Shift+Enter is pressed
//         return;
//       } else {
//         // Prevent default new line and trigger speech
//         e.preventDefault();
        
//         if (ttsText.trim() && !isSpeaking) {
//           speakText(ttsText);
//         } else if (!ttsText.trim()) {
//           setTtsError('Please enter some text first');
//         } else if (isSpeaking) {
//           setTtsError('Already speaking. Please wait or stop current speech.');
//         }
//       }
//     }
//   };

//   // NEW: Handle Enter key press in transcript area (for speaking transcript)
//   const handleTranscriptKeyDown = (e) => {
//     if (e.key === 'Enter' && !e.shiftKey) {
//       e.preventDefault();
//       if (transcript.trim() && !isSpeaking) {
//         speakText(transcript);
//       } else if (!transcript.trim()) {
//         setError('No transcript available to speak');
//       } else if (isSpeaking) {
//         setError('Already speaking. Please wait or stop current speech.');
//       }
//     }
//   };

//   const pauseSpeech = () => {
//     try {
//       window.speechSynthesis.pause();
//     } catch (err) {
//       setTtsError(`Failed to pause: ${err.message}`);
//     }
//   };

//   const resumeSpeech = () => {
//     try {
//       window.speechSynthesis.resume();
//     } catch (err) {
//       setTtsError(`Failed to resume: ${err.message}`);
//     }
//   };

//   const stopSpeech = () => {
//     try {
//       window.speechSynthesis.cancel();
//       setIsSpeaking(false);
//       setIsPaused(false);
//     } catch (err) {
//       setTtsError(`Failed to stop: ${err.message}`);
//     }
//   };

//   // Speak the current transcript
//   const speakTranscript = () => {
//     if (transcript.trim()) {
//       speakText(transcript);
//     } else {
//       setTtsError('No transcript available to speak');
//     }
//   };

//   // Existing STT functions (keeping original code)
//   const selectDevice = async (deviceId) => {
//     try {
//       console.log('Selecting device:', deviceId);
      
//       if (mediaStream) {
//         mediaStream.getTracks().forEach(track => track.stop());
//       }

//       const stream = await navigator.mediaDevices.getUserMedia({
//         audio: { 
//           deviceId: deviceId ? { exact: deviceId } : undefined,
//           echoCancellation: true,
//           noiseSuppression: true,
//           autoGainControl: true,
//           sampleRate: 16000
//         }
//       });

//       console.log('Stream created successfully');
//       setMediaStream(stream);
//       setSelectedDevice(deviceId);
//       setError('');
//     } catch (err) {
//       console.error('Device selection error:', err);
//       setError(`Error selecting device: ${err.message}`);
//     }
//   };

//   const startListening = async () => {
//     try {
//       if (!permissionGranted) {
//         setError('Microphone permission not granted. Please refresh and allow access.');
//         return;
//       }

//       if (selectedDevice) {
//         await selectDevice(selectedDevice);
//       }

//       const recognition = SpeechRecognition.getRecognition();
//       if (recognition) {
//         recognition.onerror = (event) => {
//           console.error('Speech recognition error:', event.error);
//           setError(`Speech recognition error: ${event.error}`);
//           setIsListening(false);
//         };

//         recognition.onend = () => {
//           console.log('Speech recognition ended');
//           setIsListening(false);
//         };
//       }

//       await SpeechRecognition.startListening({ 
//         continuous: true,
//         interimResults: true,
//         language: 'en-US'
//       });
      
//       setIsListening(true);
//       setError('');
//       console.log('Speech recognition started successfully');
//     } catch (err) {
//       console.error('Start listening error:', err);
//       setError(`Failed to start listening: ${err.message}`);
//       setIsListening(false);
//     }
//   };

//   const stopListening = () => {
//     try {
//       SpeechRecognition.stopListening();
//       setIsListening(false);
//       console.log('Speech recognition stopped');
//     } catch (err) {
//       console.error('Stop listening error:', err);
//       setError(`Error stopping: ${err.message}`);
//     }
//   };

//   const testMicrophone = async () => {
//     try {
//       const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
//       const audioContext = new AudioContext();
//       const analyser = audioContext.createAnalyser();
//       const microphone = audioContext.createMediaStreamSource(stream);
//       const dataArray = new Uint8Array(analyser.frequencyBinCount);
      
//       microphone.connect(analyser);
      
//       const checkVolume = () => {
//         analyser.getByteFrequencyData(dataArray);
//         const volume = dataArray.reduce((sum, value) => sum + value) / dataArray.length;
//         console.log('Microphone volume level:', volume);
//         return volume > 10;
//       };
      
//       const hasSound = checkVolume();
      
//       stream.getTracks().forEach(track => track.stop());
//       audioContext.close();
      
//       if (hasSound) {
//         setError('');
//         alert('Microphone is working! Volume detected.');
//       } else {
//         setError('Microphone connected but no audio detected. Please speak louder or check your microphone.');
//       }
//     } catch (err) {
//       setError(`Microphone test failed: ${err.message}`);
//     }
//   };

//   const clearTranscript = () => {
//     resetTranscript();
//   };

//   const copyToClipboard = async () => {
//     try {
//       await navigator.clipboard.writeText(transcript);
//       alert('Text copied to clipboard!');
//     } catch (err) {
//       console.error('Copy failed:', err);
//       const textArea = document.createElement('textarea');
//       textArea.value = transcript;
//       document.body.appendChild(textArea);
//       textArea.select();
//       document.execCommand('copy');
//       document.body.removeChild(textArea);
//       alert('Text copied to clipboard!');
//     }
//   };

//   return (
//     <div style={{ padding: '20px', maxWidth: '1000px', margin: '0 auto' }}>
//       <h1>Voice-to-Text & Text-to-Speech Interface</h1>
      
//       {/* Permission Status */}
//       <div style={{ 
//         padding: '10px', 
//         marginBottom: '20px',
//         backgroundColor: permissionGranted ? '#e8f5e8' : '#ffebee',
//         borderRadius: '4px',
//         border: `1px solid ${permissionGranted ? '#4CAF50' : '#f44336'}`
//       }}>
//         <strong>Permission Status:</strong> {permissionGranted ? '✓ Granted' : '✗ Not Granted'}
//         {!permissionGranted && (
//           <p style={{ margin: '10px 0 0 0', fontSize: '14px' }}>
//             Please refresh the page and allow microphone access when prompted.
//           </p>
//         )}
//       </div>

//       {/* Error Display */}
//       {(error || ttsError) && (
//         <div style={{ 
//           color: 'red', 
//           backgroundColor: '#ffebee', 
//           padding: '10px', 
//           borderRadius: '4px',
//           marginBottom: '20px'
//         }}>
//           {error && <div><strong>STT Error:</strong> {error}</div>}
//           {ttsError && <div><strong>TTS Error:</strong> {ttsError}</div>}
//         </div>
//       )}

//       {/* Debug Info */}
//       <div style={{ 
//         fontSize: '12px', 
//         color: '#666', 
//         marginBottom: '20px',
//         padding: '10px',
//         backgroundColor: '#f5f5f5',
//         borderRadius: '4px'
//       }}>
//         <strong>Debug Info:</strong><br/>
//         HTTPS: {isHttps ? '✓' : '✗'} | 
//         STT Support: {browserSupportsSpeechRecognition ? '✓' : '✗'} | 
//         TTS Support: {supportsTTS ? '✓' : '✗'} | 
//         Permission: {permissionGranted ? '✓' : '✗'}<br/>
//         Audio Devices: {audioDevices.length} | 
//         TTS Voices: {voices.length} | 
//         Listening: {listening ? '✓' : '✗'} | 
//         Speaking: {isSpeaking ? '✓' : '✗'}
//       </div>

//       {permissionGranted && (
//         <>
//           {/* Two-column layout for STT and TTS */}
//           <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '20px' }}>
            
//             {/* SPEECH-TO-TEXT SECTION */}
//             <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '20px' }}>
//               <h2 style={{ marginTop: '0', color: '#2196F3' }}>🎤 Speech-to-Text</h2>
              
//               {/* Device Selection */}
//               <div style={{ marginBottom: '15px' }}>
//                 <label htmlFor="device-select" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
//                   Microphone Device:
//                 </label>
//                 <select
//                   id="device-select"
//                   value={selectedDevice}
//                   onChange={(e) => selectDevice(e.target.value)}
//                   style={{ 
//                     width: '100%', 
//                     padding: '8px', 
//                     fontSize: '14px',
//                     borderRadius: '4px',
//                     border: '1px solid #ccc'
//                   }}
//                 >
//                   <option value="">Default Device</option>
//                   {audioDevices.map(device => (
//                     <option key={device.deviceId} value={device.deviceId}>
//                       {device.label || `Device ${device.deviceId.slice(0, 8)}...`}
//                     </option>
//                   ))}
//                 </select>
//               </div>

//               {/* STT Controls */}
//               <div style={{ marginBottom: '15px' }}>
//                 <button
//                   onClick={startListening}
//                   disabled={isListening || listening}
//                   style={{
//                     backgroundColor: listening ? '#4CAF50' : '#2196F3',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginRight: '10px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: listening ? 'not-allowed' : 'pointer',
//                     opacity: listening ? 0.7 : 1
//                   }}
//                 >
//                   {listening ? 'Listening...' : 'Start'}
//                 </button>

//                 <button
//                   onClick={stopListening}
//                   disabled={!listening}
//                   style={{
//                     backgroundColor: '#f44336',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginRight: '10px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: !listening ? 'not-allowed' : 'pointer',
//                     opacity: !listening ? 0.7 : 1
//                   }}
//                 >
//                   Stop
//                 </button>

//                 <button
//                   onClick={clearTranscript}
//                   style={{
//                     backgroundColor: '#FF9800',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginRight: '10px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: 'pointer'
//                   }}
//                 >
//                   Clear
//                 </button>

//                 <button
//                   onClick={testMicrophone}
//                   style={{
//                     backgroundColor: '#9C27B0',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: 'pointer'
//                   }}
//                 >
//                   Test Mic
//                 </button>
//               </div>

//               {/* Status */}
//               <p style={{ 
//                 fontSize: '14px',
//                 fontWeight: 'bold',
//                 color: listening ? '#4CAF50' : '#666',
//                 margin: '10px 0'
//               }}>
//                 Status: {listening ? '🔴 RECORDING' : '⚪ READY'}
//               </p>

//               {/* Transcript Actions */}
//               <div style={{ marginBottom: '15px' }}>
//                 <button
//                   onClick={speakTranscript}
//                   disabled={!transcript.trim() || isSpeaking}
//                   style={{
//                     backgroundColor: '#4CAF50',
//                     color: 'white',
//                     padding: '8px 16px',
//                     marginRight: '10px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '12px',
//                     cursor: (!transcript.trim() || isSpeaking) ? 'not-allowed' : 'pointer',
//                     opacity: (!transcript.trim() || isSpeaking) ? 0.7 : 1
//                   }}
//                 >
//                   🔊 Speak Transcript
//                 </button>

//                 <button
//                   onClick={copyToClipboard}
//                   disabled={!transcript}
//                   style={{
//                     backgroundColor: '#607D8B',
//                     color: 'white',
//                     padding: '8px 16px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '12px',
//                     cursor: transcript ? 'pointer' : 'not-allowed',
//                     opacity: transcript ? 1 : 0.7
//                   }}
//                 >
//                   📋 Copy
//                 </button>
//               </div>
//             </div>

//             {/* TEXT-TO-SPEECH SECTION */}
//             <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '20px' }}>
//               <h2 style={{ marginTop: '0', color: '#4CAF50' }}>🔊 Text-to-Speech</h2>
              
//               {/* Voice Selection */}
//               <div style={{ marginBottom: '15px' }}>
//                 <label htmlFor="voice-select" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
//                   Voice:
//                 </label>
//                 <select
//                   id="voice-select"
//                   value={selectedVoice?.name || ''}
//                   onChange={(e) => {
//                     const voice = voices.find(v => v.name === e.target.value);
//                     setSelectedVoice(voice);
//                   }}
//                   style={{ 
//                     width: '100%', 
//                     padding: '8px', 
//                     fontSize: '14px',
//                     borderRadius: '4px',
//                     border: '1px solid #ccc'
//                   }}
//                 >
//                   {voices.map(voice => (
//                     <option key={voice.name} value={voice.name}>
//                       {voice.name} ({voice.lang})
//                     </option>
//                   ))}
//                 </select>
//               </div>

//               {/* TTS Settings */}
//               <div style={{ marginBottom: '15px' }}>
//                 <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', fontSize: '12px' }}>
//                   <label>
//                     Rate: {speechRate}
//                     <input
//                       type="range"
//                       min="0.5"
//                       max="2"
//                       step="0.1"
//                       value={speechRate}
//                       onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
//                       style={{ width: '100%' }}
//                     />
//                   </label>
//                   <label>
//                     Pitch: {speechPitch}
//                     <input
//                       type="range"
//                       min="0.5"
//                       max="2"
//                       step="0.1"
//                       value={speechPitch}
//                       onChange={(e) => setSpeechPitch(parseFloat(e.target.value))}
//                       style={{ width: '100%' }}
//                     />
//                   </label>
//                   <label>
//                     Volume: {speechVolume}
//                     <input
//                       type="range"
//                       min="0"
//                       max="1"
//                       step="0.1"
//                       value={speechVolume}
//                       onChange={(e) => setSpeechVolume(parseFloat(e.target.value))}
//                       style={{ width: '100%' }}
//                     />
//                   </label>
//                 </div>
//               </div>

//               {/* TTS Controls */}
//               <div style={{ marginBottom: '15px' }}>
//                 <button
//                   onClick={() => speakText()}
//                   disabled={!ttsText.trim() || (isSpeaking && !isPaused)}
//                   style={{
//                     backgroundColor: '#4CAF50',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginRight: '10px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: (!ttsText.trim() || (isSpeaking && !isPaused)) ? 'not-allowed' : 'pointer',
//                     opacity: (!ttsText.trim() || (isSpeaking && !isPaused)) ? 0.7 : 1
//                   }}
//                 >
//                   Speak
//                 </button>

//                 <button
//                   onClick={isPaused ? resumeSpeech : pauseSpeech}
//                   disabled={!isSpeaking}
//                   style={{
//                     backgroundColor: '#FF9800',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginRight: '10px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: !isSpeaking ? 'not-allowed' : 'pointer',
//                     opacity: !isSpeaking ? 0.7 : 1
//                   }}
//                 >
//                   {isPaused ? 'Resume' : 'Pause'}
//                 </button>

//                 <button
//                   onClick={stopSpeech}
//                   disabled={!isSpeaking}
//                   style={{
//                     backgroundColor: '#f44336',
//                     color: 'white',
//                     padding: '10px 20px',
//                     marginBottom: '5px',
//                     border: 'none',
//                     borderRadius: '4px',
//                     fontSize: '14px',
//                     cursor: !isSpeaking ? 'not-allowed' : 'pointer',
//                     opacity: !isSpeaking ? 0.7 : 1
//                   }}
//                 >
//                   Stop
//                 </button>
//               </div>

//               {/* Status */}
//               <p style={{ 
//                 fontSize: '14px',
//                 fontWeight: 'bold',
//                 color: isSpeaking ? '#4CAF50' : '#666',
//                 margin: '10px 0'
//               }}>
//                 Status: {isSpeaking ? (isPaused ? '⏸️ PAUSED' : '🔊 SPEAKING') : '⚪ READY'}
//               </p>
//             </div>
//           </div>

//           {/* Text Areas with Enter Key Support */}
//           <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
            
//             {/* Transcript Display with Enter Key Support */}
//             <div>
//               <h3>Recognized Text:</h3>
//               <textarea
//                 value={transcript}
//                 readOnly
//                 placeholder="Spoken text will appear here... Press Enter to speak this text!"
//                 onKeyDown={handleTranscriptKeyDown}
//                 style={{
//                   width: '100%',
//                   minHeight: '150px',
//                   padding: '15px',
//                   fontSize: '16px',
//                   lineHeight: '1.5',
//                   border: '1px solid #ccc',
//                   borderRadius: '4px',
//                   backgroundColor: '#f9f9f9',
//                   resize: 'vertical',
//                   cursor: 'pointer'
//                 }}
//                 tabIndex="0"
//               />
//               <p style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
//                 Character count: {transcript.length}
//                 <span style={{ marginLeft: '15px', color: '#4CAF50', fontWeight: 'bold' }}>
//                   💡 Press Enter to speak this text!
//                 </span>
//               </p>
//             </div>

//             {/* TTS Input with Enter Key Support */}
//             <div>
//               <h3>Text to Speak:</h3>
//               <textarea
//                 value={ttsText}
//                 onChange={(e) => setTtsText(e.target.value)}
//                 onKeyDown={handleTtsKeyDown}
//                 placeholder="Enter text to convert to speech... Press Enter to speak, Shift+Enter for new line"
//                 style={{
//                   width: '100%',
//                   minHeight: '150px',
//                   padding: '15px',
//                   fontSize: '16px',
//                   lineHeight: '1.5',
//                   border: '1px solid #ccc',
//                   borderRadius: '4px',
//                   backgroundColor: 'white',
//                   resize: 'vertical'
//                 }}
//               />
//               <p style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
//                 Character count: {ttsText.length}
//                 <span style={{ marginLeft: '15px', color: '#4CAF50', fontWeight: 'bold' }}>
//                   💡 Press Enter to speak, Shift+Enter for new line
//                 </span>
//               </p>
//             </div>
//           </div>
//         </>
//       )}

//       {/* Enhanced Instructions */}
//       <div style={{ 
//         marginTop: '30px',
//         padding: '15px',
//         backgroundColor: '#e3f2fd',
//         borderRadius: '4px'
//       }}>
//         <h4>How to Use:</h4>
//         <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
//           <div>
//             <strong>Speech-to-Text:</strong>
//             <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
//               <li>Select your microphone device</li>
//               <li>Click "Start" to begin recording</li>
//               <li>Speak clearly into your microphone</li>
//               <li><strong>Press Enter</strong> in transcript area to speak the text</li>
//             </ul>
//           </div>
//           <div>
//             <strong>Text-to-Speech:</strong>
//             <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
//               <li>Choose a voice from the dropdown</li>
//               <li>Adjust rate, pitch, and volume as needed</li>
//               <li>Type text in the input area</li>
//               <li><strong>Press Enter to speak instantly!</strong></li>
//               <li>Use Shift+Enter for new lines</li>
//             </ul>
//           </div>
//         </div>
        
//         <div style={{ marginTop: '15px', fontSize: '14px' }}>
//           <strong>🚀 New Enter Key Features:</strong>
//           <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
//             <li><strong>Enter Key:</strong> Instantly triggers text-to-speech</li>
//             <li><strong>Shift+Enter:</strong> Adds new line in TTS text area</li>
//             <li><strong>Enter in Transcript:</strong> Speaks the recognized text</li>
//             <li>No need to click buttons - just type and press Enter!</li>
//           </ul>
          
//           <strong>Troubleshooting:</strong>
//           <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
//             <li><strong>No voices available:</strong> Refresh the page or try a different browser</li>
//             <li><strong>Speech not working:</strong> Ensure HTTPS connection and latest browser version</li>
//             <li><strong>Microphone issues:</strong> Check permissions and device connections</li>
//             <li><strong>Enter key not working:</strong> Make sure the textarea is focused (click on it first)</li>
//           </ul>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ExternalDeviceVoiceToText;







import React, { useState, useEffect, useRef } from 'react';
// Add this import for Next.js or if having async issues
import 'regenerator-runtime/runtime';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

// Firebase imports
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, onDisconnect } from 'firebase/database';

const ExternalDeviceVoiceToText = () => {
  // Firebase configuration - Replace with your Firebase config
  const firebaseConfig = {
  apiKey: "AIzaSyBi4imuMT5imCT-8IBULdyFqj-ZZtl68Do",
  authDomain: "regal-welder-453313-d6.firebaseapp.com",
  databaseURL: "https://regal-welder-453313-d6-default-rtdb.firebaseio.com",
  projectId: "regal-welder-453313-d6",
  storageBucket: "regal-welder-453313-d6.firebasestorage.app",
  messagingSenderId: "981360128010",
  appId: "1:981360128010:web:5176a72c013f26b8dbeff3",
  measurementId: "G-T67CCEJ8LW"
  };

  // Initialize Firebase
  const [firebaseApp, setFirebaseApp] = useState(null);
  const [database, setDatabase] = useState(null);
  const [firebaseConnected, setFirebaseConnected] = useState(false);
  const [lastCommand, setLastCommand] = useState('');
  const [commandsSent, setCommandsSent] = useState(0);

  // Existing STT state management
  const [audioDevices, setAudioDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState('');
  const [mediaStream, setMediaStream] = useState(null);
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState('');
  const [permissionGranted, setPermissionGranted] = useState(false);

  // New TTS state management
  const [ttsText, setTtsText] = useState('');
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [utterance, setUtterance] = useState(null);
  
  // TTS Settings
  const [speechRate, setSpeechRate] = useState(1);
  const [speechPitch, setSpeechPitch] = useState(1);
  const [speechVolume, setSpeechVolume] = useState(1);
  const [ttsError, setTtsError] = useState('');

  // Speech recognition hook
  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  // Command mapping for speech recognition
  const speechCommands = {
    'hi': 1,
    'hello': 2,
    'help me': 3,
    'thank you': 4
  };

  // Initialize Firebase
  useEffect(() => {
    try {
      const app = initializeApp(firebaseConfig);
      const db = getDatabase(app);
      
      setFirebaseApp(app);
      setDatabase(db);
      setFirebaseConnected(true);
      
      console.log('Firebase initialized successfully');
    } catch (error) {
      console.error('Firebase initialization error:', error);
      setError(`Firebase connection failed: ${error.message}`);
    }
  }, []);

  // Function to send data to Firebase
  const sendToFirebase = async (value, command) => {
    if (!database || !firebaseConnected) {
      setError('Firebase not connected');
      return;
    }

    try {
      const servoRef = ref(database, 'Two_way/servo');
      await set(servoRef, value);
      
      console.log(`Sent ${value} to Firebase for command: ${command}`);
      setLastCommand(`${command} → ${value}`);
      setCommandsSent(prev => prev + 1);
      
      // Clear any previous errors
      setError('');
      
      // Optional: Speak confirmation
      if (selectedVoice) {
        speakText(`Command ${command} sent successfully`);
      }
      
    } catch (error) {
      console.error('Firebase write error:', error);
      setError(`Failed to send to Firebase: ${error.message}`);
    }
  };

  // Function to process speech and send commands
  const processCommand = (text) => {
    const lowerText = text.toLowerCase().trim();
    
    // Check for exact matches first
    if (speechCommands.hasOwnProperty(lowerText)) {
      sendToFirebase(speechCommands[lowerText], lowerText);
      return true;
    }
    
    // Check for partial matches
    for (const [command, value] of Object.entries(speechCommands)) {
      if (lowerText.includes(command)) {
        sendToFirebase(value, command);
        return true;
      }
    }
    
    return false;
  };

  // Monitor transcript changes for commands
  useEffect(() => {
    if (transcript) {
      const words = transcript.split(' ');
      const lastFewWords = words.slice(-3).join(' '); // Check last 3 words
      
      // Process the latest part of the transcript
      if (processCommand(lastFewWords) || processCommand(transcript)) {
        // Command found and processed
        console.log('Command processed from transcript:', transcript);
      }
    }
  }, [transcript, database, firebaseConnected]);

  // Check HTTPS requirement
  const isHttps = window.location.protocol === 'https:' || window.location.hostname === 'localhost';

  // Check TTS support
  const supportsTTS = 'speechSynthesis' in window;

  // Browser compatibility check
  if (!browserSupportsSpeechRecognition || !supportsTTS) {
    return (
      <div style={{ padding: '20px', color: 'red' }}>
        <h2>Browser Not Supported</h2>
        <p>Your browser doesn't support speech recognition or text-to-speech.</p>
        <p>Missing features:</p>
        <ul>
          {!browserSupportsSpeechRecognition && <li>Speech Recognition</li>}
          {!supportsTTS && <li>Text-to-Speech</li>}
        </ul>
        <p>Please use Chrome (recommended), Edge, or Safari (latest version).</p>
      </div>
    );
  }

  // HTTPS requirement check
  if (!isHttps) {
    return (
      <div style={{ padding: '20px', color: 'red' }}>
        <h2>HTTPS Required</h2>
        <p>Speech recognition and synthesis require HTTPS or localhost to work.</p>
        <p>Please access this page via HTTPS or localhost.</p>
      </div>
    );
  }

  // Load TTS voices
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      console.log('Available TTS voices:', availableVoices);
      setVoices(availableVoices);
      
      // Auto-select first English voice or first available voice
      const englishVoice = availableVoices.find(voice => voice.lang.startsWith('en'));
      setSelectedVoice(englishVoice || availableVoices[0]);
    };

    loadVoices();
    
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  // Load available audio devices and request permissions
  useEffect(() => {
    const loadDevicesAndPermissions = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          }
        });
        
        setPermissionGranted(true);
        stream.getTracks().forEach(track => track.stop());
        
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioInputs = devices.filter(device => device.kind === 'audioinput');
        
        console.log('Available audio devices:', audioInputs);
        setAudioDevices(audioInputs);
        
        if (audioInputs.length > 0) {
          setSelectedDevice(audioInputs[0].deviceId);
        }
        
        setError('');
      } catch (err) {
        console.error('Permission/Device error:', err);
        setPermissionGranted(false);
        setError(`Failed to access microphone: ${err.message}. Please allow microphone access and refresh the page.`);
      }
    };

    loadDevicesAndPermissions();

    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
      }
      if (window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Manual command sending functions
  const sendManualCommand = (command, value) => {
    sendToFirebase(value, command);
  };

  // TTS Functions
  const createUtterance = (text) => {
    const newUtterance = new SpeechSynthesisUtterance(text);
    newUtterance.voice = selectedVoice;
    newUtterance.rate = speechRate;
    newUtterance.pitch = speechPitch;
    newUtterance.volume = speechVolume;

    newUtterance.onstart = () => {
      console.log('TTS started');
      setIsSpeaking(true);
      setIsPaused(false);
      setTtsError('');
    };

    newUtterance.onend = () => {
      console.log('TTS ended');
      setIsSpeaking(false);
      setIsPaused(false);
    };

    newUtterance.onerror = (event) => {
      console.error('TTS error:', event.error);
      setTtsError(`TTS Error: ${event.error}`);
      setIsSpeaking(false);
      setIsPaused(false);
    };

    newUtterance.onpause = () => {
      setIsPaused(true);
    };

    newUtterance.onresume = () => {
      setIsPaused(false);
    };

    return newUtterance;
  };

  const speakText = (text = ttsText) => {
    if (!text.trim()) {
      setTtsError('Please enter text to speak');
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const newUtterance = createUtterance(text);
      setUtterance(newUtterance);
      window.speechSynthesis.speak(newUtterance);
    } catch (err) {
      console.error('Speak error:', err);
      setTtsError(`Failed to speak: ${err.message}`);
    }
  };

  // Handle Enter key press in TTS textarea
  const handleTtsKeyDown = (e) => {
    if (e.key === 'Enter') {
      if (e.shiftKey) {
        return;
      } else {
        e.preventDefault();
        if (ttsText.trim() && !isSpeaking) {
          speakText(ttsText);
        }
      }
    }
  };

  // Handle Enter key press in transcript area
  const handleTranscriptKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (transcript.trim() && !isSpeaking) {
        speakText(transcript);
      }
    }
  };

  // Existing STT functions (keeping them the same)
  const selectDevice = async (deviceId) => {
    try {
      console.log('Selecting device:', deviceId);
      
      if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { 
          deviceId: deviceId ? { exact: deviceId } : undefined,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 16000
        }
      });

      console.log('Stream created successfully');
      setMediaStream(stream);
      setSelectedDevice(deviceId);
      setError('');
    } catch (err) {
      console.error('Device selection error:', err);
      setError(`Error selecting device: ${err.message}`);
    }
  };

  const startListening = async () => {
    try {
      if (!permissionGranted) {
        setError('Microphone permission not granted. Please refresh and allow access.');
        return;
      }

      if (selectedDevice) {
        await selectDevice(selectedDevice);
      }

      const recognition = SpeechRecognition.getRecognition();
      if (recognition) {
        recognition.onerror = (event) => {
          console.error('Speech recognition error:', event.error);
          setError(`Speech recognition error: ${event.error}`);
          setIsListening(false);
        };

        recognition.onend = () => {
          console.log('Speech recognition ended');
          setIsListening(false);
        };
      }

      await SpeechRecognition.startListening({ 
        continuous: true,
        interimResults: true,
        language: 'en-US'
      });
      
      setIsListening(true);
      setError('');
      console.log('Speech recognition started successfully');
    } catch (err) {
      console.error('Start listening error:', err);
      setError(`Failed to start listening: ${err.message}`);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    try {
      SpeechRecognition.stopListening();
      setIsListening(false);
      console.log('Speech recognition stopped');
    } catch (err) {
      console.error('Stop listening error:', err);
      setError(`Error stopping: ${err.message}`);
    }
  };

  // Other existing functions...
  const pauseSpeech = () => {
    try {
      window.speechSynthesis.pause();
    } catch (err) {
      setTtsError(`Failed to pause: ${err.message}`);
    }
  };

  const resumeSpeech = () => {
    try {
      window.speechSynthesis.resume();
    } catch (err) {
      setTtsError(`Failed to resume: ${err.message}`);
    }
  };

  const stopSpeech = () => {
    try {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
    } catch (err) {
      setTtsError(`Failed to stop: ${err.message}`);
    }
  };

  const speakTranscript = () => {
    if (transcript.trim()) {
      speakText(transcript);
    } else {
      setTtsError('No transcript available to speak');
    }
  };

  const clearTranscript = () => {
    resetTranscript();
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(transcript);
      alert('Text copied to clipboard!');
    } catch (err) {
      const textArea = document.createElement('textarea');
      textArea.value = transcript;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('Text copied to clipboard!');
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '1000px', margin: '0 auto' }}>
      <h1>Voice Command & Firebase Integration</h1>
      
      {/* Firebase Status */}
      <div style={{ 
        padding: '10px', 
        marginBottom: '20px',
        backgroundColor: firebaseConnected ? '#e8f5e8' : '#ffebee',
        borderRadius: '4px',
        border: `1px solid ${firebaseConnected ? '#4CAF50' : '#f44336'}`
      }}>
        <strong>Firebase Status:</strong> {firebaseConnected ? '✓ Connected' : '✗ Disconnected'}
        <br/>
        <strong>Commands Sent:</strong> {commandsSent}
        {lastCommand && <><br/><strong>Last Command:</strong> {lastCommand}</>}
      </div>

      {/* Voice Commands Panel */}
      <div style={{ 
        padding: '15px',
        backgroundColor: '#f0f8ff',
        borderRadius: '4px',
        marginBottom: '20px'
      }}>
        <h3 style={{ marginTop: '0', color: '#1976D2' }}>🎯 Voice Commands</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px' }}>
          <div style={{ padding: '10px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #ddd' }}>
            <strong>"Hi"</strong> → Sends 1
            <button 
              onClick={() => sendManualCommand('hi', 1)}
              style={{ marginLeft: '10px', padding: '5px 10px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
            >
              Send
            </button>
          </div>
          <div style={{ padding: '10px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #ddd' }}>
            <strong>"Hello"</strong> → Sends 2
            <button 
              onClick={() => sendManualCommand('hello', 2)}
              style={{ marginLeft: '10px', padding: '5px 10px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
            >
              Send
            </button>
          </div>
          <div style={{ padding: '10px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #ddd' }}>
            <strong>"Help me"</strong> → Sends 3
            <button 
              onClick={() => sendManualCommand('help me', 3)}
              style={{ marginLeft: '10px', padding: '5px 10px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
            >
              Send
            </button>
          </div>
          <div style={{ padding: '10px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #ddd' }}>
            <strong>"Thank you"</strong> → Sends 4
            <button 
              onClick={() => sendManualCommand('thank you', 4)}
              style={{ marginLeft: '10px', padding: '5px 10px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
            >
              Send
            </button>
          </div>
        </div>
      </div>

      {/* Permission Status */}
      <div style={{ 
        padding: '10px', 
        marginBottom: '20px',
        backgroundColor: permissionGranted ? '#e8f5e8' : '#ffebee',
        borderRadius: '4px',
        border: `1px solid ${permissionGranted ? '#4CAF50' : '#f44336'}`
      }}>
        <strong>Microphone Permission:</strong> {permissionGranted ? '✓ Granted' : '✗ Not Granted'}
      </div>

      {/* Error Display */}
      {(error || ttsError) && (
        <div style={{ 
          color: 'red', 
          backgroundColor: '#ffebee', 
          padding: '10px', 
          borderRadius: '4px',
          marginBottom: '20px'
        }}>
          {error && <div><strong>Error:</strong> {error}</div>}
          {ttsError && <div><strong>TTS Error:</strong> {ttsError}</div>}
        </div>
      )}

      {/* Debug Info */}
      <div style={{ 
        fontSize: '12px', 
        color: '#666', 
        marginBottom: '20px',
        padding: '10px',
        backgroundColor: '#f5f5f5',
        borderRadius: '4px'
      }}>
        <strong>System Status:</strong><br/>
        Firebase: {firebaseConnected ? '✓' : '✗'} | 
        HTTPS: {isHttps ? '✓' : '✗'} | 
        STT: {browserSupportsSpeechRecognition ? '✓' : '✗'} | 
        TTS: {supportsTTS ? '✓' : '✗'}<br/>
        Microphone: {permissionGranted ? '✓' : '✗'} | 
        Listening: {listening ? '✓' : '✗'} | 
        Speaking: {isSpeaking ? '✓' : '✗'}
      </div>

      {permissionGranted && (
        <>
          {/* Main Interface - keeping your existing layout */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '20px' }}>
            
            {/* SPEECH-TO-TEXT SECTION */}
            <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '20px' }}>
              <h2 style={{ marginTop: '0', color: '#2196F3' }}>🎤 Speech-to-Text + Commands</h2>
              
              {/* Device Selection */}
              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="device-select" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Microphone Device:
                </label>
                <select
                  id="device-select"
                  value={selectedDevice}
                  onChange={(e) => selectDevice(e.target.value)}
                  style={{ 
                    width: '100%', 
                    padding: '8px', 
                    fontSize: '14px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                >
                  <option value="">Default Device</option>
                  {audioDevices.map(device => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Device ${device.deviceId.slice(0, 8)}...`}
                    </option>
                  ))}
                </select>
              </div>

              {/* STT Controls */}
              <div style={{ marginBottom: '15px' }}>
                <button
                  onClick={startListening}
                  disabled={isListening || listening}
                  style={{
                    backgroundColor: listening ? '#4CAF50' : '#2196F3',
                    color: 'white',
                    padding: '10px 20px',
                    marginRight: '10px',
                    marginBottom: '5px',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: listening ? 'not-allowed' : 'pointer',
                    opacity: listening ? 0.7 : 1
                  }}
                >
                  {listening ? 'Listening for Commands...' : 'Start Listening'}
                </button>

                <button
                  onClick={stopListening}
                  disabled={!listening}
                  style={{
                    backgroundColor: '#f44336',
                    color: 'white',
                    padding: '10px 20px',
                    marginRight: '10px',
                    marginBottom: '5px',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: !listening ? 'not-allowed' : 'pointer',
                    opacity: !listening ? 0.7 : 1
                  }}
                >
                  Stop
                </button>

                <button
                  onClick={clearTranscript}
                  style={{
                    backgroundColor: '#FF9800',
                    color: 'white',
                    padding: '10px 20px',
                    marginBottom: '5px',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: 'pointer'
                  }}
                >
                  Clear
                </button>
              </div>

              {/* Status */}
              <p style={{ 
                fontSize: '14px',
                fontWeight: 'bold',
                color: listening ? '#4CAF50' : '#666',
                margin: '10px 0'
              }}>
                Status: {listening ? '🔴 LISTENING FOR COMMANDS' : '⚪ READY'}
              </p>
            </div>

            {/* TEXT-TO-SPEECH SECTION - keeping your existing TTS section */}
            <div style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '20px' }}>
              <h2 style={{ marginTop: '0', color: '#4CAF50' }}>🔊 Text-to-Speech</h2>
              
              {/* Voice Selection */}
              <div style={{ marginBottom: '15px' }}>
                <label htmlFor="voice-select" style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Voice:
                </label>
                <select
                  id="voice-select"
                  value={selectedVoice?.name || ''}
                  onChange={(e) => {
                    const voice = voices.find(v => v.name === e.target.value);
                    setSelectedVoice(voice);
                  }}
                  style={{ 
                    width: '100%', 
                    padding: '8px', 
                    fontSize: '14px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                >
                  {voices.map(voice => (
                    <option key={voice.name} value={voice.name}>
                      {voice.name} ({voice.lang})
                    </option>
                  ))}
                </select>
              </div>

              {/* TTS Settings */}
              <div style={{ marginBottom: '15px' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', fontSize: '12px' }}>
                  <label>
                    Rate: {speechRate}
                    <input
                      type="range"
                      min="0.5"
                      max="2"
                      step="0.1"
                      value={speechRate}
                      onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                      style={{ width: '100%' }}
                    />
                  </label>
                  <label>
                    Pitch: {speechPitch}
                    <input
                      type="range"
                      min="0.5"
                      max="2"
                      step="0.1"
                      value={speechPitch}
                      onChange={(e) => setSpeechPitch(parseFloat(e.target.value))}
                      style={{ width: '100%' }}
                    />
                  </label>
                  <label>
                    Volume: {speechVolume}
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={speechVolume}
                      onChange={(e) => setSpeechVolume(parseFloat(e.target.value))}
                      style={{ width: '100%' }}
                    />
                  </label>
                </div>
              </div>

              {/* TTS Controls */}
              <div style={{ marginBottom: '15px' }}>
                <button
                  onClick={() => speakText()}
                  disabled={!ttsText.trim() || (isSpeaking && !isPaused)}
                  style={{
                    backgroundColor: '#4CAF50',
                    color: 'white',
                    padding: '10px 20px',
                    marginRight: '10px',
                    marginBottom: '5px',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: (!ttsText.trim() || (isSpeaking && !isPaused)) ? 'not-allowed' : 'pointer',
                    opacity: (!ttsText.trim() || (isSpeaking && !isPaused)) ? 0.7 : 1
                  }}
                >
                  Speak
                </button>

                <button
                  onClick={isPaused ? resumeSpeech : pauseSpeech}
                  disabled={!isSpeaking}
                  style={{
                    backgroundColor: '#FF9800',
                    color: 'white',
                    padding: '10px 20px',
                    marginRight: '10px',
                    marginBottom: '5px',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: !isSpeaking ? 'not-allowed' : 'pointer',
                    opacity: !isSpeaking ? 0.7 : 1
                  }}
                >
                  {isPaused ? 'Resume' : 'Pause'}
                </button>

                <button
                  onClick={stopSpeech}
                  disabled={!isSpeaking}
                  style={{
                    backgroundColor: '#f44336',
                    color: 'white',
                    padding: '10px 20px',
                    marginBottom: '5px',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: !isSpeaking ? 'not-allowed' : 'pointer',
                    opacity: !isSpeaking ? 0.7 : 1
                  }}
                >
                  Stop
                </button>
              </div>
            </div>
          </div>

          {/* Text Areas */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
            
            {/* Transcript Display */}
            <div>
              <h3>Speech Recognition Results:</h3>
              <textarea
                value={transcript}
                readOnly
                placeholder="Say 'Hi', 'Hello', 'Help me', or 'Thank you' to send commands to Firebase..."
                onKeyDown={handleTranscriptKeyDown}
                style={{
                  width: '100%',
                  minHeight: '150px',
                  padding: '15px',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  backgroundColor: '#f9f9f9',
                  resize: 'vertical'
                }}
              />
              <p style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
                Commands will be automatically detected and sent to Firebase!
              </p>
            </div>

            {/* TTS Input */}
            <div>
              <h3>Text to Speak:</h3>
              <textarea
                value={ttsText}
                onChange={(e) => setTtsText(e.target.value)}
                onKeyDown={handleTtsKeyDown}
                placeholder="Enter text to speak... Press Enter to speak instantly!"
                style={{
                  width: '100%',
                  minHeight: '150px',
                  padding: '15px',
                  fontSize: '16px',
                  lineHeight: '1.5',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  backgroundColor: 'white',
                  resize: 'vertical'
                }}
              />
              <p style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
                💡 Press Enter to speak, Shift+Enter for new line
              </p>
            </div>
          </div>
        </>
      )}

      {/* Instructions */}
      <div style={{ 
        marginTop: '30px',
        padding: '15px',
        backgroundColor: '#e3f2fd',
        borderRadius: '4px'
      }}>
        <h4>🚀 Firebase Voice Commands:</h4>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          <div>
            <strong>Voice Commands:</strong>
            <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
              <li><strong>"Hi"</strong> → Sends 1 to Two_way/servo</li>
              <li><strong>"Hello"</strong> → Sends 2 to Two_way/servo</li>
              <li><strong>"Help me"</strong> → Sends 3 to Two_way/servo</li>
              <li><strong>"Thank you"</strong> → Sends 4 to Two_way/servo</li>
            </ul>
          </div>
          <div>
            <strong>How it works:</strong>
            <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
              <li>Start speech recognition</li>
              <li>Say any of the command phrases</li>
              <li>Command is automatically detected</li>
              <li>Value is sent to Firebase instantly</li>
              <li>Confirmation is shown in the status panel</li>
            </ul>
          </div>
        </div>
        
        <div style={{ marginTop: '15px', fontSize: '14px' }}>
          <strong>Setup Instructions:</strong>
          <ol style={{ margin: '10px 0', paddingLeft: '20px' }}>
            <li>Replace the Firebase config with your project credentials</li>
            <li>Ensure Firebase Realtime Database is set up</li>
            <li>Set database rules to allow writes to 'Two_way/servo'</li>
            <li>Test with manual buttons first, then try voice commands</li>
          </ol>
        </div>
      </div>
    </div>
  );
};

export default ExternalDeviceVoiceToText;
